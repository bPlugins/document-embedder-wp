<?php
/**
 * BPLDE AJAX Call Controller.
 *
 * @package DocumentEmbedder
 */

namespace BPLDE\Model;

use BPLDE\Helper\Functions;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'AJAXCall' ) ) {
    class AJAXCall {
        protected static $_instance = null;

        public static function instance() {
            if ( self::$_instance === null ) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        public function __construct() {
            // 1. Leads REST / Export
            add_action( 'wp_ajax_de_export_leads_csv', [$this, 'handle_export_csv'] );

            // 2. Document Library
            add_action( 'wp_ajax_bplde_save_document_library', [$this, 'bplde_save_document_library'] );   
            add_action( 'wp_ajax_bplde_get_single', [$this, 'bplde_get_single'] );
            add_action( 'wp_ajax_bplde_delete_document_library', [$this, 'bplde_delete_document_library'] );
            add_action( 'wp_ajax_bplde_get_all', [$this, 'bplde_get_all'] );

            // 3. Track download
            add_action( 'wp_ajax_de_track_download', [$this, 'de_track_download'] );
            add_action( 'wp_ajax_nopriv_de_track_download', [$this, 'de_track_download'] );

            // 4. Get Doc Meta
            add_action( 'wp_ajax_pdfp_get_doc_meta', [$this, 'single_doc_callback'] );
        }

        // --- Leads CSV Export Handlers ---
        public function handle_export_csv() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( 'Unauthorized' );
            }

            $doc_id = isset( $_GET['doc_id'] ) ? intval( $_GET['doc_id'] ) : 0;
            if ( ! $doc_id ) {
                wp_die( 'Invalid document ID' );
            }

            check_admin_referer( 'de_export_leads_csv', 'nonce' );

            global $wpdb;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $leads = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, name, email, document_id, document_title, downloaded_at, ip_address FROM {$wpdb->prefix}docembedder_leads WHERE document_id = %d ORDER BY downloaded_at DESC",
                $doc_id
            ), ARRAY_A );

            header( 'Content-Type: text/csv' );
            header( 'Content-Disposition: attachment; filename="doc-leads-' . $doc_id . '-' . gmdate( 'Y-m-d' ) . '.csv"' );
            header( 'Pragma: no-cache' );
            header( 'Expires: 0' );

            $output = fopen( 'php://output', 'w' );
            fputcsv( $output, ['ID', 'Name', 'Email', 'Document ID', 'Document Title', 'Downloaded At', 'IP Address'] );

            foreach ( $leads as $lead ) {
                fputcsv( $output, array_map( [Functions::class, 'escape_csv_field'], $lead ) );
            }

            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- php://output has no WP_Filesystem equivalent
            fclose( $output );
            exit;
        }

        // --- Document Library Handlers ---
        public function bplde_save_document_library() {
            check_ajax_referer( 'bplde_nonce', 'nonce' );

            if ( ! current_user_can( 'edit_posts' ) ) {
                wp_send_json_error( ['message' => 'Unauthorized.'] );
            }
        
            $id       = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;
            $title    = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : 'Untitled';
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- recursive sanitization applied via $sanitize_settings() below
            $settings = isset( $_POST['settings'] ) ? json_decode( wp_unslash( $_POST['settings'] ), true ) : [];

            // Deep validation & recursive sanitization of settings array
            $sanitize_settings = function( $array ) use ( &$sanitize_settings ) {
                if ( ! is_array( $array ) ) {
                    return sanitize_text_field( $array );
                }
                $clean = [];
                foreach ( $array as $key => $val ) {
                    $clean_key = preg_replace( '/[^a-zA-Z0-9_\-]/', '', $key );
                    if ( is_array( $val ) ) {
                        $clean[$clean_key] = $sanitize_settings( $val );
                    } else {
                        if ( Functions::is_unsafe_url( $val ) ) {
                            // "javascript:alert(1)" fails FILTER_VALIDATE_URL and would
                            // otherwise be stored by sanitize_text_field() untouched.
                            $clean[$clean_key] = '';
                        } elseif ( filter_var( $val, FILTER_VALIDATE_URL ) ) {
                            $clean[$clean_key] = esc_url_raw( $val );
                        } elseif ( is_numeric( $val ) ) {
                            $clean[$clean_key] = $val;
                        } elseif ( is_bool( $val ) ) {
                            $clean[$clean_key] = $val;
                        } else {
                            $clean[$clean_key] = sanitize_text_field( $val );
                        }
                    }
                }
                return $clean;
            };
            $settings = $sanitize_settings( $settings );

            $post_data = [
                'post_title'  => $title,
                'post_type'   => 'document_library',
                'post_status' => 'publish',
            ];
        
            if ( $id > 0 ) {
                if ( ! current_user_can( 'edit_post', $id ) ) {
                    wp_send_json_error( ['message' => 'Unauthorized to edit this document.'] );
                }

                $post_data['ID'] = $id;
                $result = wp_update_post( $post_data, true );
            } else {
                $result = wp_insert_post( $post_data, true );
            }
        
            if ( is_wp_error( $result ) ) {
                wp_send_json_error( ['message' => $result->get_error_message()] );
            } else {
                update_post_meta( $result, 'bplde_settings', $settings );

                wp_send_json_success( [
                    'id'       => $result,
                    'settings' => $settings,
                    'created'  => get_the_date( 'Y/m/d \a\t g:i a', $result )
                ] );
            }
        }

        public function bplde_get_single() {
            check_ajax_referer( 'bplde_nonce', 'nonce' );

            $id = intval( $_GET['id'] ?? 0 );
        
            if ( ! $id ) {
                wp_send_json_error( ['message' => 'Invalid ID'] );
            }

            $post = get_post( $id );

            if ( ! $post ) {
                wp_send_json_error( ['message' => 'Post not found'] );
            }
            
            if ( ! current_user_can( 'edit_post', $id ) ) {
                wp_send_json_error( ['message' => 'Unauthorized.'] );
            }
        
            $settings = get_post_meta( $id, 'bplde_settings', true );
            $settings = Functions::strip_unsafe_urls( $settings, ['url'] );
        
            wp_send_json_success( [
                'id'       => $id,
                'title'    => $post->post_title,
                'settings' => $settings,
                'created'  => get_the_date( 'Y/m/d \a\t g:i a', $id )
            ] );
        }

        public function bplde_get_all() {
            check_ajax_referer( 'bplde_nonce', 'nonce' );

            if ( ! current_user_can( 'edit_posts' ) ) {
                wp_send_json_error( ['message' => 'Unauthorized.'] );
            }
        
            $query = new \WP_Query( [
                'post_type'      => 'document_library',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'author'         => get_current_user_id(),
            ] );
        
            $items = [];
            foreach ( $query->posts as $post ) {
                $settings = get_post_meta( $post->ID, 'bplde_settings', true );
                $settings = Functions::strip_unsafe_urls( $settings, ['url'] );
        
                $items[] = [
                    'id'       => $post->ID,
                    'title'    => $post->post_title,
                    'settings' => $settings,
                    'created'  => get_the_date( 'Y/m/d \a\t g:i a', $post )
                ];
            }
        
            wp_send_json_success( $items );
        }

        public function bplde_delete_document_library() {
            check_ajax_referer( 'bplde_nonce', 'nonce' );
           
            $id = intval( $_POST['id'] ?? 0 );
            if ( ! $id ) {
                wp_send_json_error( ['message' => 'Invalid ID'] );
            }

            if ( ! current_user_can( 'delete_post', $id ) ) {
                wp_send_json_error( ['message' => 'Unauthorized to delete this document.'] );
            }
            
            wp_delete_post( $id, true );
            wp_send_json_success();
        }

        // --- Track Download Handler ---
        public function de_track_download() {
            check_ajax_referer( 'de_track_download_nonce', 'nonce' );
            
            $document_id = isset( $_POST['document_id'] ) ? intval( $_POST['document_id'] ) : 0;

            // The nonce above is CSRF protection only. It is printed for every visitor,
            // including anonymous ones, so it says nothing about who is asking or what they
            // are entitled to -- the document itself has to be checked before a token is
            // issued for it. Unauthorized IDs fall through to the existing "Invalid document
            // ID" response, which the front end already handles by downloading the embedded
            // file directly, so a legitimate visitor sees no change.
            if ( $document_id > 0 && Functions::can_read_document( $document_id ) ) {
                global $wpdb;

                $ip = Functions::get_client_ip();

                // Refuse before the row is written, not after. Every row inserted here counts
                // against the per-IP limit and bumps the download counter, so a refusal left
                // to the delivery endpoint is recorded as a download that never happened --
                // and that endpoint answers with a bare JSON 403 body the viewer cannot read
                // or render, so the visitor would just be navigated onto it.
                if ( Functions::download_limit_reached( $document_id, $ip ) ) {
                    wp_send_json_error( [
                        'message'       => __( 'Download limit reached.', 'document-emberdder' ),
                        'limit_reached' => true,
                        'count'         => (int) get_post_meta( $document_id, '_de_download_count', true ),
                    ] );
                }

                // Record in leads table for IP tracking
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- direct insert to custom table
                $wpdb->insert(
                    $wpdb->prefix . 'docembedder_leads',
                    [
                        'name'           => 'Anonymous',
                        'email'          => 'anonymous@direct.download',
                        'document_id'    => $document_id,
                        'document_title' => get_the_title( $document_id ),
                        'downloaded_at'  => current_time( 'mysql' ),
                        'ip_address'     => $ip
                    ],
                    ['%s', '%s', '%d', '%s', '%s', '%s']
                );

                // A custom token rather than a WP nonce, to stay UID-independent across the
                // redirect. Carries its own issue time so it expires; see create_download_token().
                $token = Functions::create_download_token( $document_id );

                $count = (int) get_post_meta( $document_id, '_de_download_count', true );
                update_post_meta( $document_id, '_de_download_count', $count + 1 );

                wp_send_json_success( [
                    // Site-wide total, which is what the "(N downloads)" label shows.
                    'count'         => $count + 1,
                    // Whether this visitor may download again is a per-IP question and a
                    // different number entirely, so it is answered here rather than left to
                    // the front end to infer from the total above -- comparing a site-wide
                    // count against a per-IP limit locks the button after one download on any
                    // document that already has history.
                    'limit_reached' => Functions::download_limit_reached( $document_id, $ip ),
                    'nonce'         => $token
                ] );
            }
            wp_send_json_error( [ 'message' => __( 'Invalid document ID', 'document-emberdder' ) ] );
        }

        // --- Get Doc Meta Handlers ---
        public function single_doc_callback() {
            $id    = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( $_GET['id'] ) ) : false;
            $nonce = isset( $_GET['ppv_nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['ppv_nonce'] ) ) : false;
            $user     = wp_get_current_user();
            if ( ! $id || get_post_status( $id ) != 'publish' || ! wp_verify_nonce( $nonce, 'ppv_secret_nonce' ) || ! in_array( 'administrator', $user->roles ) ) {
                return false;
            }

            $data = $this->get_data( $id );
           
            echo wp_json_encode( $data );
            die();
        }

        private function get_data( $id ) {
            $width  = Functions::meta( $id, 'width', ['width' => '100', 'unit' => '%'] );
            $height = Functions::meta( $id, 'height', ['height' => 600, 'unit' => 'px'] );

            return [
                'url'      => Functions::meta( $id, 'doc', '' ),
                'width'    => $width['width'] . $width['unit'],
                'height'   => $height['height'] . $height['unit'],
                'showName' => Functions::meta( $id, 'showName' ),
                'title'    => get_the_title( $id )
            ];
        }
    }

    AJAXCall::instance();
}

<?php
/**
 * BPLDocumentEmbedder class.
 *
 * @package DocumentEmbedder
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('BPLDE_Document_Embedder')) {
    class BPLDE_Document_Embedder {

        private static $_instance = null;

        public static function instance()
        {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        public function __construct() {
            add_action('plugins_loaded', [$this, 'load_dependencies']);
            add_action('admin_init', [$this, 'assign_file_type_to_all']);
            add_action('save_post_ppt_viewer', [$this, 'sync_post_file_type'], 10, 2);
            add_action('before_delete_post', [$this, 'delete_document_leads'], 10, 2);
            add_action('wp_enqueue_scripts', [$this, 'ppv_public_scripts']);

            add_action('add_meta_boxes', [$this, 'add_stats_metabox']);
            add_action('add_meta_boxes', [$this, 'add_sidebar_cards']);
            add_filter('get_user_option_meta-box-order_ppt_viewer', [$this, 'release_sidebar_cards']);

            $db_ver = get_option('de_db_version', '0');
            if (version_compare($db_ver, BPLDE_VER, '<')) {
                $this->ensure_table_exists();
            } 


        }

        public function load_dependencies() {
            class_exists('\BPLDE\Admin\BPLDE_Menu');
            class_exists('\BPLDE\PostType\PPTViewer');
            class_exists('\BPLDE\Model\Shortcode');
            class_exists('\BPLDE\Model\AJAXCall');
            new \BPLDE\Rest\RESTController();
            if (is_admin()) {
                class_exists('\BPLDE\Admin\LeadsPage');
            }

            if (class_exists('\BPLDE_Block')) {
                new \BPLDE_Block();
            }

            if (!class_exists('CSF')) {
                require_once BPLDE_PLUGIN_PATH . 'vendor/Codestar/framework.php';
            }

            class_exists('\BPLDE_Settings_Free');
            class_exists('\BPLDE_Metabox_Free');
        }

        public function ppv_public_scripts() {
            wp_enqueue_script('ppv-public', BPLDE_PLUGIN_DIR . 'build/public.js', array('jquery'), BPLDE_VER, true);
            wp_localize_script('ppv-public', 'bplde_obj', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'track_nonce' => wp_create_nonce('de_track_download_nonce'),
                // Cookie authentication on a REST route is only honoured when a wp_rest
                // nonce comes with it, so without this a logged-in editor is seen as
                // anonymous by the download route and cannot fetch their own unpublished
                // document. Emitted for logged-in users only, and deliberately so: an
                // expired nonce makes WordPress reject the request outright, which would
                // turn a cached page into a broken download for anonymous visitors.
                'rest_nonce' => is_user_logged_in() ? wp_create_nonce('wp_rest') : '',
                'rest_url' => get_rest_url(null, 'docembedder/v1/')
            ));
            wp_enqueue_style('ppv-public', BPLDE_PLUGIN_DIR . 'build/public.css', array(), BPLDE_VER);
        }

        public function assign_file_type_to_all() {
            if (get_option('de_file_type_migrated', '0') === '1') {
                return;
            }

            $batch_size = 50;
            $offset = intval(get_option('de_migration_offset', 0));

            $args = array(
                'post_type' => 'ppt_viewer',
                'posts_per_page' => $batch_size,
                'offset' => $offset,
                'post_status' => 'any',
                'fields' => 'ids',
            );
            $post_ids = get_posts($args);

            if (empty($post_ids)) {
                update_option('de_file_type_migrated', '1');
                delete_option('de_migration_offset');
                return;
            }

            foreach ($post_ids as $post_id) {
                $data = get_post_meta($post_id, 'ppv', true);
                $file_url = isset($data['doc']) ? $data['doc'] : '';
                if ($file_url) {
                    $ext = strtolower(pathinfo($file_url, PATHINFO_EXTENSION));
                    if ($ext) {
                        wp_set_object_terms($post_id, $ext, 'ppv_file_type', false);
                    }
                }
            }

            update_option('de_migration_offset', $offset + count($post_ids));
        }

        public function sync_post_file_type($post_id, $post = null)
        {
            if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
                return;
            }

            $data = get_post_meta($post_id, 'ppv', true);
            $file_url = isset($data['doc']) ? $data['doc'] : '';
            if ($file_url) {
                $ext = strtolower(pathinfo($file_url, PATHINFO_EXTENSION));
                if ($ext) {
                    wp_set_object_terms($post_id, $ext, 'ppv_file_type', false);
                }
            }
        }

        /**
         * Leads follow the download count: both belong to the document, so both go when
         * the document does.
         *
         * before_delete_post fires on permanent deletion only, which is the same point
         * WordPress drops the _de_download_count meta. Trashing a document therefore
         * keeps its leads, and restoring it from the trash brings them back with it.
         *
         * Rows already orphaned by documents deleted before this existed are left alone
         * — removing someone's captured leads during a plugin update is not an upgrade.
         *
         * @param int          $post_id Post being deleted.
         * @param \WP_Post|null $post    Post object, passed by WordPress since 5.5.
         */
        public function delete_document_leads($post_id, $post = null)
        {
            $post_type = ($post instanceof \WP_Post) ? $post->post_type : get_post_type($post_id);

            if ($post_type !== 'ppt_viewer') {
                return;
            }

            global $wpdb;

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom table
            $wpdb->delete(
                $wpdb->prefix . 'docembedder_leads',
                ['document_id' => (int) $post_id],
                ['%d']
            );
        }

        public function de_track_download()
        {
            \BPLDE\Model\AJAXCall::instance()->de_track_download();
        }

        public function add_stats_metabox() {
            add_meta_box(
                'ppv_download_stats',
                'Download Stats',
                [$this, 'render_stats_metabox'],
                'ppt_viewer',
                'side',
                'default'
            );
        }

        public function render_stats_metabox($post)
        {
            global $wpdb;
            $count = get_post_meta($post->ID, '_de_download_count', true);
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- querying custom table
            $leads_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}docembedder_leads WHERE document_id = %d", $post->ID));
            $leads_url = admin_url('edit.php?post_type=ppt_viewer&page=bplde-download-leads&filter_document_id=' . $post->ID);
            ?>
            <div class="de-stats-container bplde-stats">
                <div class="bplde-stats__grid">
                    <div class="bplde-stat">
                        <span class="bplde-stat__value"><?php echo esc_html(number_format_i18n(intval($count))); ?></span>
                        <span class="bplde-stat__label"><?php esc_html_e('Downloads', 'document-emberdder'); ?></span>
                    </div>
                    <div class="bplde-stat">
                        <span class="bplde-stat__value"><?php echo esc_html(number_format_i18n(intval($leads_count))); ?></span>
                        <span class="bplde-stat__label"><?php esc_html_e('Leads', 'document-emberdder'); ?></span>
                    </div>
                </div>
                <a href="<?php echo esc_url($leads_url); ?>" class="bplde-stats__cta">
                    <?php esc_html_e('View leads', 'document-emberdder'); ?>
                </a>
            </div>
            <?php
        }

        /**
         * The panels that sit under Download Stats in the side column: the page-builder
         * note and the Pro teaser. Registered on a second add_meta_boxes callback so they
         * land after the stats box in the column. This is the free build, so the teaser is
         * unconditional — no licence check gates it.
         *
         * Publish and the taxonomy boxes register at the 'core' priority, which WordPress
         * renders ahead of 'default', so the column reads Publish, Tags, Download Stats,
         * builder note. The Pro teaser takes 'low' to close the column out — the same order
         * the Pro build uses, so upgrading does not shuffle the sidebar.
         */
        public function add_sidebar_cards() {
            add_meta_box(
                'bplde_builders',
                esc_html__('Page Builder Support', 'document-emberdder'),
                [$this, 'render_builders_metabox'],
                'ppt_viewer',
                'side',
                'default'
            );

            add_filter('postbox_classes_ppt_viewer_bplde_builders', [$this, 'flat_postbox_class']);

            add_meta_box(
                'bplde_pro_teaser',
                esc_html__('Document Embedder Pro', 'document-emberdder'),
                [$this, 'render_pro_teaser_metabox'],
                'ppt_viewer',
                'side',
                'low'
            );

            add_filter('postbox_classes_ppt_viewer_bplde_pro_teaser', [$this, 'flat_postbox_class']);
        }

        /**
         * A box named in the user's stored meta-box order is rendered from the 'sorted'
         * bucket, which WordPress draws before 'core' — that is how these cards ended up
         * above Publish once an older layout had been saved, and hiding the drag handles
         * means it cannot be undone by dragging. Dropping our IDs out of the stored
         * string hands them back to their priorities, and leaves every other box the
         * user arranged exactly where they put it.
         */
        public function release_sidebar_cards($order)
        {
            if (!is_array($order) || empty($order['side'])) {
                return $order;
            }

            $ours = ['ppv_download_stats', 'bplde_pro_teaser', 'bplde_builders'];
            $kept = array_diff(explode(',', $order['side']), $ours);

            $order['side'] = implode(',', $kept);

            return $order;
        }

        /**
         * The panel draws its own surface, so the postbox chrome around it is stripped
         * in CSS. Hiding .postbox-header also removes the toggle and the drag handle,
         * which is what keeps the card open and in place.
         */
        public function flat_postbox_class($classes)
        {
            $classes[] = 'bplde-flat-box';

            return $classes;
        }

        /**
         * Free-only upgrade panel. The email gate is listed first because this renders
         * directly under the leads and download counts, which is where that feature
         * explains itself.
         */
        public function render_pro_teaser_metabox()
        {
            $features = [
                __('Email-gated downloads', 'document-emberdder'),
                __('Interactive overlays on any page', 'document-emberdder'),
                __('Print, copy and right-click protection', 'document-emberdder'),
                __('Access limited by user role', 'document-emberdder'),
                __('Google Drive and Dropbox embeds', 'document-emberdder'),
                __('Toolbar themes, zoom and lightbox', 'document-emberdder'),
            ];

            $pricing_url = \BPLDE\Helper\Functions::pricing_url();
            ?>
            <div class="bplde-panel">
                <p class="bplde-panel__badge"><?php esc_html_e('Pro', 'document-emberdder'); ?></p>

                <h4 class="bplde-panel__title"><?php esc_html_e('Where the free version stops', 'document-emberdder'); ?></h4>

                <ul class="bplde-panel__list">
                    <?php foreach ($features as $feature) { ?>
                        <li><?php echo esc_html($feature); ?></li>
                    <?php } ?>
                </ul>

                <a href="<?php echo esc_url($pricing_url); ?>" class="bplde-panel__cta">
                    <?php esc_html_e('See Pro pricing', 'document-emberdder'); ?>
                </a>

                <p class="bplde-panel__foot">
                    <?php esc_html_e('14-day refund policy', 'document-emberdder'); ?>
                </p>
            </div>
            <?php
        }

        /**
         * Builder compatibility card. The builder names are chips rather than a
         * sentence: the list is scanned, not read, and a run of seven names inside
         * prose is the slowest possible way to answer "is mine supported?".
         *
         * It deliberately does not repeat the shortcode — that lives once, under the
         * post title, so there is only one copy of it to keep correct.
         */
        public function render_builders_metabox()
        {
            $builders = ['Elementor', 'Divi', 'Bricks', 'WPBakery', 'Beaver Builder', 'Oxygen', 'Breakdance'];

            ?>
            <div class="bplde-panel bplde-builders">
                <div class="bplde-builders__head">
                    <span class="bplde-builders__check" aria-hidden="true">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                            stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 6L9 17l-5-5" />
                        </svg>
                    </span>
                    <h4 class="bplde-builders__title"><?php esc_html_e('Works in every builder', 'document-emberdder'); ?></h4>
                </div>

                <p class="bplde-builders__note"><?php esc_html_e('Drop the shortcode into any of these.', 'document-emberdder'); ?></p>

                <ul class="bplde-builders__chips">
                    <?php foreach ($builders as $builder) { ?>
                        <li class="bplde-chip"><?php echo esc_html($builder); ?></li>
                    <?php } ?>
                </ul>
            </div>
            <?php
        }

        public function ensure_table_exists()
        {
            global $wpdb;
            $table_name = $wpdb->prefix . 'docembedder_leads';
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- querying custom table existence
            if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) != $table_name) {
                \BPLDEDocumentEmbedder::activate();
            }
            update_option('de_db_version', BPLDE_VER);
        }

    }
}
